<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Block displaying attendance leaderboard.
 *
 * @package    block_attendanceleaderboard
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Block attendance leaderboard class definition.
 *
 * @package    block_attendanceleaderboard
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_attendanceleaderboard extends block_base {

    /**
     * Initialize the block.
     */
    public function init() {
        $this->title = get_string('blocktitle', 'block_attendanceleaderboard');
    }

    /**
     * This block can be added to a course.
     */
    public function applicable_formats() {
        return [
            'all' => false,
            'site' => false,
            'course' => true,
            'course-category' => false,
            'my' => true
        ];
    }

    /**
     * This block has instance specific configuration.
     */
    public function instance_allow_config() {
        return true;
    }

    /**
     * This block has global configuration.
     */
    public function has_config() {
        return false;
    }

    /**
     * Returns true if multiple instances of this block are allowed.
     */
    public function instance_allow_multiple() {
        return true;
    }

    /**
     * Specialization.
     * Happens right after the initialisation is complete.
     */
    public function specialization() {
        if (isset($this->config->title)) {
            $this->title = format_string($this->config->title);
        } else {
            $this->title = get_string('blocktitle', 'block_attendanceleaderboard');
        }
    }

    /**
     * Get content for this block.
     */
    public function get_content() {
        global $OUTPUT, $COURSE, $USER;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        // If we're not in a course, don't show anything.
        if ($COURSE->id == SITEID) {
            return $this->content;
        }

        // Check if the attendance module is installed.
        if (!\core_component::get_component_directory('mod_attendance')) {
            $this->content->text = get_string('nostudents', 'block_attendanceleaderboard');
            return $this->content;
        }

        // Get the leaderboard data.
        $manager = new \block_attendanceleaderboard\leaderboard_manager($COURSE->id);
        
        // Determine how many students to show.
        $displaytype = isset($this->config->displaytype) ? $this->config->displaytype : 'top';
        $numbertodisplay = isset($this->config->numbertodisplay) ? $this->config->numbertodisplay : 5;
        $nameformat = isset($this->config->nameformat) ? $this->config->nameformat : 'initial';
        
        // Get the leaderboard data.
        $limit = ($displaytype == 'all') ? 0 : $numbertodisplay;
        $scores = $manager->get_leaderboard($limit);

        if (empty($scores)) {
            $this->content->text = get_string('nostudents', 'block_attendanceleaderboard');
            return $this->content;
        }

        // Prepare the data for rendering.
        $entries = [];
        $rank = 1;
        $maxPoints = 0;
        
        // Find max points for progress bar calculation
        foreach ($scores as $score) {
            if (is_object($score)) {
                $score = (array)$score;
            }
            $points = isset($score['points']) ? (int)$score['points'] : 0;
            if ($points > $maxPoints) {
                $maxPoints = $points;
            }
        }
        
        // If no points, set a minimum for visualization
        if ($maxPoints == 0) {
            $maxPoints = 10;
        }
        
        foreach ($scores as $score) {
            // Ensure we have array data (convert from object if needed)
            if (is_object($score)) {
                $score = (array)$score;
            }
            
            // Create user object with all required fields
            $user = new stdClass();
            $user->id = isset($score['userid']) ? (int)$score['userid'] : 0;
            $user->firstname = isset($score['firstname']) ? $score['firstname'] : '';
            $user->lastname = isset($score['lastname']) ? $score['lastname'] : '';
            $user->email = isset($score['email']) ? $score['email'] : '';
            $user->picture = isset($score['picture']) ? (int)$score['picture'] : 0;
            $user->imagealt = isset($score['imagealt']) ? $score['imagealt'] : '';
            $user->firstnamephonetic = '';
            $user->lastnamephonetic = '';
            $user->middlename = '';
            $user->alternatename = '';

            $entry = new stdClass();
            $entry->rank = $rank;
            
            // Safe user picture with error handling
            try {
                if ($user->id > 0) {
                    $entry->picture = $OUTPUT->user_picture($user, ['size' => 35]);
                } else {
                    $entry->picture = '';
                }
            } catch (Exception $e) {
                $entry->picture = '';
            }
            
            // Safe fullname with error handling - Format based on configuration
            try {
                if ($user->id > 0) {
                    if ($nameformat === 'full') {
                        // Full name format: "Firstname Lastname"
                        $entry->fullname = fullname($user);
                    } else {
                        // Initial format: "Firstname L."
                        $firstname = trim($user->firstname);
                        $lastname = trim($user->lastname);
                        $lastnameinitial = !empty($lastname) ? strtoupper(substr($lastname, 0, 1)) . '.' : '';
                        $entry->fullname = $firstname . (!empty($lastnameinitial) ? ' ' . $lastnameinitial : '');
                    }
                } else {
                    if ($nameformat === 'full') {
                        // Full name format
                        $entry->fullname = trim($user->firstname) . ' ' . trim($user->lastname);
                    } else {
                        // Initial format
                        $firstname = trim($user->firstname);
                        $lastname = trim($user->lastname);
                        $lastnameinitial = !empty($lastname) ? strtoupper(substr($lastname, 0, 1)) . '.' : '';
                        $entry->fullname = $firstname . (!empty($lastnameinitial) ? ' ' . $lastnameinitial : '');
                    }
                }
            } catch (Exception $e) {
                if ($nameformat === 'full') {
                    // Full name format as fallback
                    $entry->fullname = trim($user->firstname) . ' ' . trim($user->lastname);
                } else {
                    // Initial format as fallback
                    $firstname = trim($user->firstname);
                    $lastname = trim($user->lastname);
                    $lastnameinitial = !empty($lastname) ? strtoupper(substr($lastname, 0, 1)) . '.' : '';
                    $entry->fullname = $firstname . (!empty($lastnameinitial) ? ' ' . $lastnameinitial : '');
                }
            }
            
            $points = isset($score['points']) ? (int)$score['points'] : 0;
            $activitypoints = isset($score['activitypoints']) ? (int)$score['activitypoints'] : 0;
            $attendancepoints = $points - $activitypoints;
            
            $entry->points = $points;
            $entry->present = isset($score['present']) ? (int)$score['present'] : 0;
            $entry->late = isset($score['late']) ? (int)$score['late'] : 0;
            $entry->excused = isset($score['excused']) ? (int)$score['excused'] : 0;
            $entry->absent = isset($score['absent']) ? (int)$score['absent'] : 0;
            $entry->activitypoints = $activitypoints;
            $entry->attendancepoints = $attendancepoints;
            
            // Calculate progress percentage (0-100)
            $entry->progress = $maxPoints > 0 ? min(100, round(($points / $maxPoints) * 100)) : 0;

            // Add ranking flags for template
            $entry->is_rank_1 = ($rank === 1);
            $entry->is_rank_2 = ($rank === 2);
            $entry->is_rank_3 = ($rank === 3);

            $entries[] = $entry;
            $rank++;
        }

        // Render the leaderboard.
        $data = [
            'entries' => $entries,
            'nostudents' => get_string('nostudents', 'block_attendanceleaderboard')
        ];

        $this->content->text = $OUTPUT->render_from_template('block_attendanceleaderboard/leaderboard', $data);

        return $this->content;
    }

    /**
     * HTML attributes for the block.
     */
    public function html_attributes() {
        $attributes = parent::html_attributes();
        $attributes['class'] .= ' block_attendanceleaderboard';
        return $attributes;
    }

    /**
     * Create content for the edit form.
     */
    public function instance_config_save($data, $nolongerused = false) {
        // Clean some data before saving it.
        if (isset($data->numbertodisplay)) {
            $data->numbertodisplay = clean_param($data->numbertodisplay, PARAM_INT);
        }
        
        if (isset($data->nameformat)) {
            $data->nameformat = clean_param($data->nameformat, PARAM_ALPHA);
            // Validate nameformat value
            if (!in_array($data->nameformat, ['full', 'initial'])) {
                $data->nameformat = 'initial'; // Default to initial format
            }
        }

        parent::instance_config_save($data, $nolongerused);
    }

    /**
     * Return an array of formats to cache the content with.
     */
    public function get_content_caching_key_for_current_user() {
        global $USER;
        return [$USER->id];
    }
}