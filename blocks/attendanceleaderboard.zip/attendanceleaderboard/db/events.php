<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observers for block_attendanceleaderboard
 *
 * @package    block_attendanceleaderboard
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$observers = array(
    array(
        'eventname'   => '\mod_attendance\event\attendance_taken',
        'callback'    => '\block_attendanceleaderboard\observer::attendance_taken',
    ),
    array(
        'eventname'   => '\mod_attendance\event\attendance_taken_by_student',
        'callback'    => '\block_attendanceleaderboard\observer::attendance_taken_by_student',
    ),
    array(
        'eventname'   => '\mod_attendance\event\session_updated',
        'callback'    => '\block_attendanceleaderboard\observer::session_updated',
    ),
    array(
        'eventname'   => '\mod_attendance\event\session_deleted',
        'callback'    => '\block_attendanceleaderboard\observer::session_deleted',
    ),
    array(
        'eventname'   => '\core\event\course_module_deleted',
        'callback'    => '\block_attendanceleaderboard\observer::course_module_deleted',
        'includefile' => null,
        'internal'    => true,
    ),
); 