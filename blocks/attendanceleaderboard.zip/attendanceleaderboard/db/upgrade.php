<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade script for block_attendanceleaderboard.
 *
 * @package    block_attendanceleaderboard
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade function for block_attendanceleaderboard.
 *
 * @param int $oldversion The old version of the plugin.
 * @return bool
 */
function xmldb_block_attendanceleaderboard_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2025052300) {
        // Membersihkan cache yang mungkin ada dari versi sebelumnya.
        $cache = \cache::make('block_attendanceleaderboard', 'leaderboarddata');
        $cache->purge();

        // Memperbarui semua data skor untuk memastikan konsistensi.
        $courses = $DB->get_records_select('course', 'id > ?', [SITEID]);
        foreach ($courses as $course) {
            $manager = new \block_attendanceleaderboard\leaderboard_manager($course->id);
            $manager->refresh_data();
        }

        upgrade_block_savepoint(true, 2025052300, 'attendanceleaderboard');
    }

    if ($oldversion < 2025062500) {
        // Define field activitypoints to be added to block_attendanceleaderboard_scores.
        $table = new xmldb_table('block_attendanceleaderboard_scores');
        $field = new xmldb_field('activitypoints', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'absent');

        // Conditionally launch add field activitypoints.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Attendanceleaderboard savepoint reached.
        upgrade_block_savepoint(true, 2025062500, 'attendanceleaderboard');
    }

    return true;
} 