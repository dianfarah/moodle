<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for attendance leaderboard block (Indonesian)
 *
 * @package    block_attendanceleaderboard
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Papan Peringkat Kehadiran';
$string['attendanceleaderboard'] = 'Papan Peringkat Kehadiran';
$string['attendanceleaderboard:addinstance'] = 'Tambahkan blok Papan Peringkat Kehadiran baru';
$string['attendanceleaderboard:myaddinstance'] = 'Tambahkan blok Papan Peringkat Kehadiran baru ke Dasbor';
$string['blocktitle'] = 'Papan Peringkat Kehadiran';
$string['configtitle'] = 'Judul blok';
$string['configdisplaytype'] = 'Tipe tampilan';
$string['displaytype_all'] = 'Tampilkan semua siswa';
$string['displaytype_top'] = 'Tampilkan siswa teratas';
$string['numbertodisplay'] = 'Jumlah siswa yang ditampilkan';
$string['confignameformat'] = 'Format tampilan nama';
$string['nameformat_full'] = 'Nama lengkap (Nama Depan Nama Belakang)';
$string['nameformat_initial'] = 'Nama depan + inisial (Nama Depan B.)';
$string['nostudents'] = 'Tidak ada siswa untuk ditampilkan';
$string['rankheading'] = 'Peringkat';
$string['studentheading'] = 'Siswa';
$string['pointsheading'] = 'Poin';
$string['presentheading'] = 'Hadir';
$string['lateheading'] = 'Terlambat';
$string['excusedheading'] = 'Izin';
$string['absentheading'] = 'Tidak Hadir';
$string['privacy:metadata:block_attendanceleaderboard_scores'] = 'Informasi tentang skor kehadiran pengguna dalam kursus untuk peringkat papan peringkat';
$string['privacy:metadata:block_attendanceleaderboard_scores:courseid'] = 'ID kursus tempat pengguna diberi peringkat';
$string['privacy:metadata:block_attendanceleaderboard_scores:userid'] = 'ID pengguna yang diberi peringkat';
$string['privacy:metadata:block_attendanceleaderboard_scores:points'] = 'Poin pengguna';
$string['privacy:metadata:block_attendanceleaderboard_scores:present'] = 'Jumlah sesi hadir';
$string['privacy:metadata:block_attendanceleaderboard_scores:late'] = 'Jumlah sesi terlambat';
$string['privacy:metadata:block_attendanceleaderboard_scores:excused'] = 'Jumlah sesi izin';
$string['privacy:metadata:block_attendanceleaderboard_scores:absent'] = 'Jumlah sesi tidak hadir';