<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for attendance leaderboard block
 *
 * @package    block_attendanceleaderboard
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Attendance Leaderboard';
$string['attendanceleaderboard'] = 'Attendance Leaderboard';
$string['attendanceleaderboard:addinstance'] = 'Add a new Attendance Leaderboard block';
$string['attendanceleaderboard:myaddinstance'] = 'Add a new Attendance Leaderboard block to Dashboard';
$string['blocktitle'] = 'Attendance Leaderboard';
$string['configtitle'] = 'Block title';
$string['configdisplaytype'] = 'Display type';
$string['displaytype_all'] = 'Show all students';
$string['displaytype_top'] = 'Show top students';
$string['numbertodisplay'] = 'Number of students to display';
$string['confignameformat'] = 'Name display format';
$string['nameformat_full'] = 'Full name (Firstname Lastname)';
$string['nameformat_initial'] = 'First name + initial (Firstname L.)';
$string['nostudents'] = 'No students to display';
$string['rankheading'] = 'Rank';
$string['studentheading'] = 'Student';
$string['pointsheading'] = 'Points';
$string['presentheading'] = 'Present';
$string['lateheading'] = 'Late';
$string['excusedheading'] = 'Excused';
$string['absentheading'] = 'Absent';
$string['privacy:metadata:block_attendanceleaderboard_scores'] = 'Information about the attendance scores of a user in a course for leaderboard ranking';
$string['privacy:metadata:block_attendanceleaderboard_scores:courseid'] = 'The ID of the course the user is ranked in';
$string['privacy:metadata:block_attendanceleaderboard_scores:userid'] = 'The ID of the user who is ranked';
$string['privacy:metadata:block_attendanceleaderboard_scores:points'] = 'The points of the user';
$string['privacy:metadata:block_attendanceleaderboard_scores:present'] = 'The number of present sessions';
$string['privacy:metadata:block_attendanceleaderboard_scores:late'] = 'The number of late sessions';
$string['privacy:metadata:block_attendanceleaderboard_scores:excused'] = 'The number of excused sessions';
$string['privacy:metadata:block_attendanceleaderboard_scores:absent'] = 'The number of absent sessions';